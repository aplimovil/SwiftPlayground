/*:
 # iOS Development with Swift
 ## Introduction to Swift Programming Language
 
- [TypeInference](TypeInference)
- [Collections](Collections)
- [ControlFlow](ControlFlow)
- [Functions](Functions)
- [Optionals](Optionals)
- [Tuples](Tuples)
- [HigherOrderFunctions](HigherOrderFunctions)
- [Classes (Distance Class Example)](Classes)
- [Class Inheritance (Telephone Class Example)](ClassesInheritance)
- [Protocols (Telephone Protocols Example)](Protocols)
- [Structures (Distance Structure Example)](Structures)
 ****
    
 */
